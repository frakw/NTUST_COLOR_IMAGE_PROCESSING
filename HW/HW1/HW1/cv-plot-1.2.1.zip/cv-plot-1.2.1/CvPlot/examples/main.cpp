// CvPlot - https://github.com/Profactor/cv-plot
// Copyright (c) 2019 by PROFACTOR GmbH - https://www.profactor.at/

#define CATCH_CONFIG_MAIN
#include <catch.hpp>
