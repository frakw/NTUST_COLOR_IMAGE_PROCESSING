# Other C++ OpenCV Plotting Libraries

There are many plotting libraries out there for Python, Javascript, .NET, Qt, ...
The only pure C++ OpenCV libraries that I found are

## OpenCV Plot Contrib Module
https://github.com/opencv/opencv_contrib/tree/master/modules/plot

Quite disappointing for a contrib module. Very view features. No documentation. No axes.

## Leonardvandriel's cvplot
https://github.com/leonardvandriel/cvplot

Much better. Clean interface and a lot of features. But no way to add custom drawables.
