![contours](img/contours.PNG)

![series](img/series.png)

![lenna](img/lenna.PNG)

![show](img/show.gif)

![zoom-contours](img/zoom-contours.gif)

![zoom-lenna](img/zoom-lenna.gif)

![zoom-series](img/zoom-series.gif)

![double-matrix](img/double-matrix.PNG)

![drag](img/drag.gif)

![logarithmic](img/logarithmic.PNG)

![mandelbrot](img/mandelbrot.gif)

![no-margin](img/no-margin.PNG)

![one-minute](img/one-minute.png)

![paint](img/paint.gif)

![pixels](img/pixels.png)

![profile](img/profile.gif)

![benchmark](img/benchmark.gif)
